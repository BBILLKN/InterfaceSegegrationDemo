/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package interfacesegregationdemo;

/**
 *
 * @author BILL_0058
 */
public class Main {
    public static void main(String[] args) {
        // Objek mobil
        Car car = new Car();
        car.startEngine();
        car.stopEngine();

        // Objek pesawat
        Airplanes airplane = new Airplanes();
        airplane.startEngine();
        airplane.fly();
        airplane.stopEngine();
    }
}

