/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package interfacesegregationdemo;

/**
 *
 * @author BILL_0058
 */
public class Airplanes implements EngineOperations, Flyable {

    @Override
    public void startEngine() {
        System.out.println("Pesawat: Mesin dinyalakan.");
    }

    @Override
    public void stopEngine() {
        System.out.println("Pesawat: Mesin dimatikan.");
    }

    @Override
    public void fly() {
        System.out.println("Pesawat: Terbang di udara.");
    }
}

