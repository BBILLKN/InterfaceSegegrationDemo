/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package interfacesegregationdemo;

/**
 *
 * @author BILL_0058
 */
public class Car implements EngineOperations {

    @Override
    public void startEngine() {
        System.out.println("Mobil: Mesin dinyalakan.");
    }

    @Override
    public void stopEngine() {
        System.out.println("Mobil: Mesin dimatikan.");
    }
}

